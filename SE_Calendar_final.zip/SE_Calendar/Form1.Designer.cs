﻿namespace SE_Calendar
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelLogin = new System.Windows.Forms.SplitContainer();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.button17 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.label4 = new System.Windows.Forms.Label();
            this.panelCreateAccount = new System.Windows.Forms.SplitContainer();
            this.button8 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panelCreateAccountSuccess = new System.Windows.Forms.SplitContainer();
            this.button9 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.panelAddEvent = new System.Windows.Forms.SplitContainer();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.monthCalendar2 = new System.Windows.Forms.MonthCalendar();
            this.button10 = new System.Windows.Forms.Button();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panelAddEventSuccess = new System.Windows.Forms.SplitContainer();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.splitContainer7 = new System.Windows.Forms.SplitContainer();
            this.button32 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.label18 = new System.Windows.Forms.Label();
            this.splitContainer9 = new System.Windows.Forms.SplitContainer();
            this.button35 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.splitContainer8 = new System.Windows.Forms.SplitContainer();
            this.label31 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.splitContainer10 = new System.Windows.Forms.SplitContainer();
            this.button16 = new System.Windows.Forms.Button();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.splitContainer11 = new System.Windows.Forms.SplitContainer();
            this.button18 = new System.Windows.Forms.Button();
            this.checkedListBox2 = new System.Windows.Forms.CheckedListBox();
            this.label32 = new System.Windows.Forms.Label();
            this.splitContainer12 = new System.Windows.Forms.SplitContainer();
            this.button19 = new System.Windows.Forms.Button();
            this.checkedListBox3 = new System.Windows.Forms.CheckedListBox();
            this.label33 = new System.Windows.Forms.Label();
            this.splitContainer13 = new System.Windows.Forms.SplitContainer();
            this.button20 = new System.Windows.Forms.Button();
            this.checkedListBox4 = new System.Windows.Forms.CheckedListBox();
            this.label34 = new System.Windows.Forms.Label();
            this.checkedListBox5 = new System.Windows.Forms.CheckedListBox();
            this.label35 = new System.Windows.Forms.Label();
            this.panelInvalidUsername = new System.Windows.Forms.SplitContainer();
            this.label36 = new System.Windows.Forms.Label();
            this.button21 = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.panelInvalidPassword = new System.Windows.Forms.SplitContainer();
            this.label38 = new System.Windows.Forms.Label();
            this.button22 = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.panelCreateErrorPasswords = new System.Windows.Forms.SplitContainer();
            this.label40 = new System.Windows.Forms.Label();
            this.button23 = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.panelCreateErrorEmptyUsername = new System.Windows.Forms.SplitContainer();
            this.label42 = new System.Windows.Forms.Label();
            this.button24 = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.panelCreateErrorUsernameExists = new System.Windows.Forms.SplitContainer();
            this.label44 = new System.Windows.Forms.Label();
            this.button25 = new System.Windows.Forms.Button();
            this.label45 = new System.Windows.Forms.Label();
            this.panelAddEventErrorInvalidTime = new System.Windows.Forms.SplitContainer();
            this.label46 = new System.Windows.Forms.Label();
            this.button26 = new System.Windows.Forms.Button();
            this.label47 = new System.Windows.Forms.Label();
            this.panelAddEventErrorInvalidLength = new System.Windows.Forms.SplitContainer();
            this.label48 = new System.Windows.Forms.Label();
            this.button27 = new System.Windows.Forms.Button();
            this.label49 = new System.Windows.Forms.Label();
            this.panelAddEventErrorConflicts = new System.Windows.Forms.SplitContainer();
            this.label50 = new System.Windows.Forms.Label();
            this.button28 = new System.Windows.Forms.Button();
            this.label51 = new System.Windows.Forms.Label();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.label52 = new System.Windows.Forms.Label();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.button31 = new System.Windows.Forms.Button();
            this.label53 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.button36 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.checkedListBox6 = new System.Windows.Forms.CheckedListBox();
            this.label54 = new System.Windows.Forms.Label();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.button34 = new System.Windows.Forms.Button();
            this.label55 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.panelLogin)).BeginInit();
            this.panelLogin.Panel1.SuspendLayout();
            this.panelLogin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelCreateAccount)).BeginInit();
            this.panelCreateAccount.Panel1.SuspendLayout();
            this.panelCreateAccount.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelCreateAccountSuccess)).BeginInit();
            this.panelCreateAccountSuccess.Panel1.SuspendLayout();
            this.panelCreateAccountSuccess.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelAddEvent)).BeginInit();
            this.panelAddEvent.Panel1.SuspendLayout();
            this.panelAddEvent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelAddEventSuccess)).BeginInit();
            this.panelAddEventSuccess.Panel1.SuspendLayout();
            this.panelAddEventSuccess.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).BeginInit();
            this.splitContainer7.Panel1.SuspendLayout();
            this.splitContainer7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).BeginInit();
            this.splitContainer9.Panel1.SuspendLayout();
            this.splitContainer9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).BeginInit();
            this.splitContainer8.Panel1.SuspendLayout();
            this.splitContainer8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer10)).BeginInit();
            this.splitContainer10.Panel1.SuspendLayout();
            this.splitContainer10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).BeginInit();
            this.splitContainer11.Panel1.SuspendLayout();
            this.splitContainer11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer12)).BeginInit();
            this.splitContainer12.Panel1.SuspendLayout();
            this.splitContainer12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer13)).BeginInit();
            this.splitContainer13.Panel1.SuspendLayout();
            this.splitContainer13.Panel2.SuspendLayout();
            this.splitContainer13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelInvalidUsername)).BeginInit();
            this.panelInvalidUsername.Panel1.SuspendLayout();
            this.panelInvalidUsername.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelInvalidPassword)).BeginInit();
            this.panelInvalidPassword.Panel1.SuspendLayout();
            this.panelInvalidPassword.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelCreateErrorPasswords)).BeginInit();
            this.panelCreateErrorPasswords.Panel1.SuspendLayout();
            this.panelCreateErrorPasswords.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelCreateErrorEmptyUsername)).BeginInit();
            this.panelCreateErrorEmptyUsername.Panel1.SuspendLayout();
            this.panelCreateErrorEmptyUsername.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelCreateErrorUsernameExists)).BeginInit();
            this.panelCreateErrorUsernameExists.Panel1.SuspendLayout();
            this.panelCreateErrorUsernameExists.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelAddEventErrorInvalidTime)).BeginInit();
            this.panelAddEventErrorInvalidTime.Panel1.SuspendLayout();
            this.panelAddEventErrorInvalidTime.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelAddEventErrorInvalidLength)).BeginInit();
            this.panelAddEventErrorInvalidLength.Panel1.SuspendLayout();
            this.panelAddEventErrorInvalidLength.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelAddEventErrorConflicts)).BeginInit();
            this.panelAddEventErrorConflicts.Panel1.SuspendLayout();
            this.panelAddEventErrorConflicts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).BeginInit();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLogin
            // 
            this.panelLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelLogin.Location = new System.Drawing.Point(211, 25);
            this.panelLogin.Name = "panelLogin";
            this.panelLogin.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // panelLogin.Panel1
            // 
            this.panelLogin.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelLogin.Panel1.Controls.Add(this.button2);
            this.panelLogin.Panel1.Controls.Add(this.button1);
            this.panelLogin.Panel1.Controls.Add(this.textBox2);
            this.panelLogin.Panel1.Controls.Add(this.textBox1);
            this.panelLogin.Panel1.Controls.Add(this.label3);
            this.panelLogin.Panel1.Controls.Add(this.label2);
            this.panelLogin.Panel1.Controls.Add(this.label1);
            // 
            // panelLogin.Panel2
            // 
            this.panelLogin.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelLogin.Size = new System.Drawing.Size(802, 535);
            this.panelLogin.SplitterDistance = 479;
            this.panelLogin.SplitterWidth = 5;
            this.panelLogin.TabIndex = 0;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(282, 342);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(208, 45);
            this.button2.TabIndex = 6;
            this.button2.Text = "Create Account";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(326, 263);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 45);
            this.button1.TabIndex = 5;
            this.button1.Text = "Login";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(362, 188);
            this.textBox2.Name = "textBox2";
            this.textBox2.PasswordChar = '*';
            this.textBox2.Size = new System.Drawing.Size(162, 26);
            this.textBox2.TabIndex = 4;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(362, 118);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(162, 26);
            this.textBox1.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(116, 186);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(116, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Username";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(284, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Login ";
            // 
            // splitContainer2
            // 
            this.splitContainer2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.splitContainer2.Location = new System.Drawing.Point(174, 17);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.button17);
            this.splitContainer2.Panel1.Controls.Add(this.listBox1);
            this.splitContainer2.Panel1.Controls.Add(this.label10);
            this.splitContainer2.Panel1.Controls.Add(this.button7);
            this.splitContainer2.Panel1.Controls.Add(this.button6);
            this.splitContainer2.Panel1.Controls.Add(this.button5);
            this.splitContainer2.Panel1.Controls.Add(this.button4);
            this.splitContainer2.Panel1.Controls.Add(this.button3);
            this.splitContainer2.Panel1.Controls.Add(this.monthCalendar1);
            this.splitContainer2.Panel1.Controls.Add(this.label4);
            this.splitContainer2.Size = new System.Drawing.Size(911, 606);
            this.splitContainer2.SplitterDistance = 559;
            this.splitContainer2.SplitterWidth = 5;
            this.splitContainer2.TabIndex = 1;
            this.splitContainer2.Visible = false;
            // 
            // button17
            // 
            this.button17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.Location = new System.Drawing.Point(224, 502);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(160, 35);
            this.button17.TabIndex = 9;
            this.button17.Text = "Schedule Meeting";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Visible = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Items.AddRange(new object[] {
            "04/8/2025 : Teams Evaluation",
            "04/17/2025 : Conference Call With Clients",
            "04/26/2025 : Doctor Appointment",
            "04/26/2025 : Project discussion"});
            this.listBox1.Location = new System.Drawing.Point(436, 135);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(348, 284);
            this.listBox1.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(508, 97);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(200, 25);
            this.label10.TabIndex = 7;
            this.label10.Text = "Monthly Events List";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(56, 502);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(138, 35);
            this.button7.TabIndex = 6;
            this.button7.Text = "Monthly Events";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(224, 445);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(160, 34);
            this.button6.TabIndex = 5;
            this.button6.Text = "Event Details";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(56, 445);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(118, 34);
            this.button5.TabIndex = 4;
            this.button5.Text = "Edit Event";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(224, 389);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(160, 32);
            this.button4.TabIndex = 3;
            this.button4.Text = "Delete Event";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(56, 389);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(118, 32);
            this.button3.TabIndex = 2;
            this.button3.Text = "Add Event";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(56, 95);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.SelectionRange = new System.Windows.Forms.SelectionRange(new System.DateTime(2025, 1, 1, 0, 0, 0, 0), new System.DateTime(2025, 1, 7, 0, 0, 0, 0));
            this.monthCalendar1.TabIndex = 1;
            this.monthCalendar1.TodayDate = new System.DateTime(2025, 4, 26, 0, 0, 0, 0);
            this.monthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(321, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(172, 36);
            this.label4.TabIndex = 0;
            this.label4.Text = "Main Menu";
            // 
            // panelCreateAccount
            // 
            this.panelCreateAccount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelCreateAccount.Location = new System.Drawing.Point(237, 17);
            this.panelCreateAccount.Name = "panelCreateAccount";
            this.panelCreateAccount.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // panelCreateAccount.Panel1
            // 
            this.panelCreateAccount.Panel1.Controls.Add(this.button8);
            this.panelCreateAccount.Panel1.Controls.Add(this.textBox5);
            this.panelCreateAccount.Panel1.Controls.Add(this.textBox4);
            this.panelCreateAccount.Panel1.Controls.Add(this.textBox3);
            this.panelCreateAccount.Panel1.Controls.Add(this.label8);
            this.panelCreateAccount.Panel1.Controls.Add(this.label7);
            this.panelCreateAccount.Panel1.Controls.Add(this.label6);
            this.panelCreateAccount.Panel1.Controls.Add(this.label5);
            this.panelCreateAccount.Size = new System.Drawing.Size(800, 598);
            this.panelCreateAccount.SplitterDistance = 486;
            this.panelCreateAccount.SplitterWidth = 5;
            this.panelCreateAccount.TabIndex = 2;
            this.panelCreateAccount.Visible = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(273, 288);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(195, 45);
            this.button8.TabIndex = 7;
            this.button8.Text = "Create Account";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(398, 215);
            this.textBox5.Name = "textBox5";
            this.textBox5.PasswordChar = '*';
            this.textBox5.Size = new System.Drawing.Size(134, 26);
            this.textBox5.TabIndex = 6;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(398, 168);
            this.textBox4.Name = "textBox4";
            this.textBox4.PasswordChar = '*';
            this.textBox4.Size = new System.Drawing.Size(134, 26);
            this.textBox4.TabIndex = 5;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(398, 117);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(134, 26);
            this.textBox3.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(170, 218);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(187, 25);
            this.label8.TabIndex = 3;
            this.label8.Text = "Confirm Password";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(170, 168);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(106, 25);
            this.label7.TabIndex = 2;
            this.label7.Text = "Password";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(168, 115);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 25);
            this.label6.TabIndex = 1;
            this.label6.Text = "Username";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(200, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(306, 36);
            this.label5.TabIndex = 0;
            this.label5.Text = "Create New Account";
            // 
            // panelCreateAccountSuccess
            // 
            this.panelCreateAccountSuccess.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelCreateAccountSuccess.Location = new System.Drawing.Point(208, 102);
            this.panelCreateAccountSuccess.Name = "panelCreateAccountSuccess";
            this.panelCreateAccountSuccess.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // panelCreateAccountSuccess.Panel1
            // 
            this.panelCreateAccountSuccess.Panel1.Controls.Add(this.button9);
            this.panelCreateAccountSuccess.Panel1.Controls.Add(this.label9);
            this.panelCreateAccountSuccess.Size = new System.Drawing.Size(784, 475);
            this.panelCreateAccountSuccess.SplitterDistance = 301;
            this.panelCreateAccountSuccess.SplitterWidth = 5;
            this.panelCreateAccountSuccess.TabIndex = 8;
            this.panelCreateAccountSuccess.Visible = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(296, 163);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(170, 58);
            this.button9.TabIndex = 1;
            this.button9.Text = "Return Login";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.ReturnToLoginEvent);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(128, 62);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(512, 36);
            this.label9.TabIndex = 0;
            this.label9.Text = "New Account Created Successfully";
            // 
            // panelAddEvent
            // 
            this.panelAddEvent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelAddEvent.Location = new System.Drawing.Point(154, 95);
            this.panelAddEvent.Name = "panelAddEvent";
            this.panelAddEvent.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // panelAddEvent.Panel1
            // 
            this.panelAddEvent.Panel1.Controls.Add(this.textBox20);
            this.panelAddEvent.Panel1.Controls.Add(this.textBox9);
            this.panelAddEvent.Panel1.Controls.Add(this.comboBox3);
            this.panelAddEvent.Panel1.Controls.Add(this.monthCalendar2);
            this.panelAddEvent.Panel1.Controls.Add(this.button10);
            this.panelAddEvent.Panel1.Controls.Add(this.textBox10);
            this.panelAddEvent.Panel1.Controls.Add(this.textBox8);
            this.panelAddEvent.Panel1.Controls.Add(this.textBox7);
            this.panelAddEvent.Panel1.Controls.Add(this.textBox6);
            this.panelAddEvent.Panel1.Controls.Add(this.label16);
            this.panelAddEvent.Panel1.Controls.Add(this.label15);
            this.panelAddEvent.Panel1.Controls.Add(this.label14);
            this.panelAddEvent.Panel1.Controls.Add(this.label13);
            this.panelAddEvent.Panel1.Controls.Add(this.label12);
            this.panelAddEvent.Panel1.Controls.Add(this.label11);
            this.panelAddEvent.Size = new System.Drawing.Size(910, 545);
            this.panelAddEvent.SplitterDistance = 436;
            this.panelAddEvent.SplitterWidth = 5;
            this.panelAddEvent.TabIndex = 9;
            this.panelAddEvent.Visible = false;
            // 
            // textBox20
            // 
            this.textBox20.ForeColor = System.Drawing.Color.Gray;
            this.textBox20.Location = new System.Drawing.Point(356, 245);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(70, 26);
            this.textBox20.TabIndex = 17;
            this.textBox20.Text = "0-59...";
            this.textBox20.Click += new System.EventHandler(this.textBox20_Click);
            this.textBox20.Leave += new System.EventHandler(this.textBox20_Leave);
            // 
            // textBox9
            // 
            this.textBox9.ForeColor = System.Drawing.Color.Gray;
            this.textBox9.Location = new System.Drawing.Point(268, 245);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(70, 26);
            this.textBox9.TabIndex = 16;
            this.textBox9.Text = "1-12...";
            this.textBox9.Click += new System.EventHandler(this.textBox9_Click);
            this.textBox9.Leave += new System.EventHandler(this.textBox9_Leave);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "AM",
            "PM"});
            this.comboBox3.Location = new System.Drawing.Point(441, 245);
            this.comboBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(62, 28);
            this.comboBox3.TabIndex = 15;
            // 
            // monthCalendar2
            // 
            this.monthCalendar2.Location = new System.Drawing.Point(528, 102);
            this.monthCalendar2.Margin = new System.Windows.Forms.Padding(14);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.TabIndex = 12;
            this.monthCalendar2.Visible = false;
            this.monthCalendar2.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar2_DateSelected);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Location = new System.Drawing.Point(396, 383);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(94, 45);
            this.button10.TabIndex = 11;
            this.button10.Text = "Add";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(268, 286);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(235, 26);
            this.textBox10.TabIndex = 10;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(268, 202);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(235, 26);
            this.textBox8.TabIndex = 8;
            this.textBox8.Click += new System.EventHandler(this.textBox8_Click);
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(268, 160);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(235, 26);
            this.textBox7.TabIndex = 7;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(268, 120);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(235, 26);
            this.textBox6.TabIndex = 6;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(38, 291);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(191, 25);
            this.label16.TabIndex = 5;
            this.label16.Text = "Event Length (hrs)";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(38, 248);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(121, 25);
            this.label15.TabIndex = 4;
            this.label15.Text = "Event Time";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(38, 205);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(118, 25);
            this.label14.TabIndex = 3;
            this.label14.Text = "Event Date";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(38, 162);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(181, 25);
            this.label13.TabIndex = 2;
            this.label13.Text = "Event Description";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(38, 118);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(129, 25);
            this.label12.TabIndex = 1;
            this.label12.Text = "Event Name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(360, 43);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(163, 36);
            this.label11.TabIndex = 0;
            this.label11.Text = "Add Event";
            // 
            // panelAddEventSuccess
            // 
            this.panelAddEventSuccess.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelAddEventSuccess.Location = new System.Drawing.Point(158, 71);
            this.panelAddEventSuccess.Name = "panelAddEventSuccess";
            this.panelAddEventSuccess.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // panelAddEventSuccess.Panel1
            // 
            this.panelAddEventSuccess.Panel1.Controls.Add(this.button12);
            this.panelAddEventSuccess.Panel1.Controls.Add(this.button11);
            this.panelAddEventSuccess.Panel1.Controls.Add(this.label17);
            this.panelAddEventSuccess.Size = new System.Drawing.Size(920, 465);
            this.panelAddEventSuccess.SplitterDistance = 420;
            this.panelAddEventSuccess.SplitterWidth = 5;
            this.panelAddEventSuccess.TabIndex = 10;
            this.panelAddEventSuccess.Visible = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.Location = new System.Drawing.Point(500, 197);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(152, 40);
            this.button12.TabIndex = 2;
            this.button12.Text = "Main Menu";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.Location = new System.Drawing.Point(262, 200);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(164, 42);
            this.button11.TabIndex = 1;
            this.button11.Text = "Add Event";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click_1);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(302, 118);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(359, 29);
            this.label17.TabIndex = 0;
            this.label17.Text = "Successfully added the event ";
            // 
            // splitContainer7
            // 
            this.splitContainer7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.splitContainer7.Location = new System.Drawing.Point(124, 17);
            this.splitContainer7.Name = "splitContainer7";
            this.splitContainer7.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer7.Panel1
            // 
            this.splitContainer7.Panel1.Controls.Add(this.button32);
            this.splitContainer7.Panel1.Controls.Add(this.button13);
            this.splitContainer7.Panel1.Controls.Add(this.checkedListBox1);
            this.splitContainer7.Panel1.Controls.Add(this.label18);
            this.splitContainer7.Size = new System.Drawing.Size(964, 577);
            this.splitContainer7.SplitterDistance = 505;
            this.splitContainer7.SplitterWidth = 5;
            this.splitContainer7.TabIndex = 11;
            this.splitContainer7.Visible = false;
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.Red;
            this.button32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button32.Location = new System.Drawing.Point(502, 350);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(109, 51);
            this.button32.TabIndex = 3;
            this.button32.Text = "Back";
            this.button32.UseVisualStyleBackColor = false;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.Location = new System.Drawing.Point(307, 347);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(106, 54);
            this.button13.TabIndex = 2;
            this.button13.Text = "Delete";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "04/26/2025: Doctor Appointment",
            "04/26/2025: Project Discussion"});
            this.checkedListBox1.Location = new System.Drawing.Point(274, 115);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(362, 188);
            this.checkedListBox1.TabIndex = 1;
            this.checkedListBox1.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox1_ItemCheck);
            this.checkedListBox1.SelectedIndexChanged += new System.EventHandler(this.checkedListBox1_SelectedIndexChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(320, 54);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(278, 36);
            this.label18.TabIndex = 0;
            this.label18.Text = "Events Associated";
            // 
            // splitContainer9
            // 
            this.splitContainer9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.splitContainer9.Location = new System.Drawing.Point(99, 9);
            this.splitContainer9.Name = "splitContainer9";
            this.splitContainer9.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer9.Panel1
            // 
            this.splitContainer9.Panel1.Controls.Add(this.button35);
            this.splitContainer9.Panel1.Controls.Add(this.button15);
            this.splitContainer9.Panel1.Controls.Add(this.textBox14);
            this.splitContainer9.Panel1.Controls.Add(this.textBox13);
            this.splitContainer9.Panel1.Controls.Add(this.textBox12);
            this.splitContainer9.Panel1.Controls.Add(this.textBox11);
            this.splitContainer9.Panel1.Controls.Add(this.label24);
            this.splitContainer9.Panel1.Controls.Add(this.label23);
            this.splitContainer9.Panel1.Controls.Add(this.label22);
            this.splitContainer9.Panel1.Controls.Add(this.label21);
            this.splitContainer9.Panel1.Controls.Add(this.label20);
            this.splitContainer9.Size = new System.Drawing.Size(938, 545);
            this.splitContainer9.SplitterDistance = 375;
            this.splitContainer9.SplitterWidth = 5;
            this.splitContainer9.TabIndex = 13;
            this.splitContainer9.Visible = false;
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.Red;
            this.button35.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button35.Location = new System.Drawing.Point(504, 270);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(148, 54);
            this.button35.TabIndex = 10;
            this.button35.Text = "Back";
            this.button35.UseVisualStyleBackColor = false;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.Location = new System.Drawing.Point(245, 272);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(156, 58);
            this.button15.TabIndex = 9;
            this.button15.Text = "Save ";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click_1);
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(476, 211);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(176, 26);
            this.textBox14.TabIndex = 8;
            this.textBox14.Text = "2 hours";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(476, 172);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(176, 26);
            this.textBox13.TabIndex = 7;
            this.textBox13.Text = "11:00 AM";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(476, 132);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(176, 26);
            this.textBox12.TabIndex = 6;
            this.textBox12.Text = "04/28/2025";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(476, 95);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(176, 26);
            this.textBox11.TabIndex = 5;
            this.textBox11.Text = "Doctor\'s Appointment";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(218, 211);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(139, 25);
            this.label24.TabIndex = 4;
            this.label24.Text = "Event Length";
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(212, 172);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(121, 25);
            this.label23.TabIndex = 3;
            this.label23.Text = "Event Time";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(208, 129);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(118, 25);
            this.label22.TabIndex = 2;
            this.label22.Text = "Event Date";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(208, 94);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(129, 25);
            this.label21.TabIndex = 1;
            this.label21.Text = "Event Name";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(350, 38);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(152, 36);
            this.label20.TabIndex = 0;
            this.label20.Text = "Edit Form";
            // 
            // splitContainer8
            // 
            this.splitContainer8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.splitContainer8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.splitContainer8.Location = new System.Drawing.Point(154, 28);
            this.splitContainer8.Name = "splitContainer8";
            this.splitContainer8.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer8.Panel1
            // 
            this.splitContainer8.Panel1.Controls.Add(this.label31);
            this.splitContainer8.Panel1.Controls.Add(this.button14);
            this.splitContainer8.Panel1.Controls.Add(this.label19);
            this.splitContainer8.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer8_Panel1_Paint);
            this.splitContainer8.Size = new System.Drawing.Size(932, 514);
            this.splitContainer8.SplitterDistance = 383;
            this.splitContainer8.SplitterWidth = 5;
            this.splitContainer8.TabIndex = 12;
            this.splitContainer8.Visible = false;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(430, 88);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(318, 36);
            this.label31.TabIndex = 2;
            this.label31.Text = "Unauthorized Access";
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Location = new System.Drawing.Point(374, 198);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(164, 48);
            this.button14.TabIndex = 1;
            this.button14.Text = "Main Menu";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(162, 88);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(232, 36);
            this.label19.TabIndex = 0;
            this.label19.Text = "Error Message:";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // splitContainer10
            // 
            this.splitContainer10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.splitContainer10.Location = new System.Drawing.Point(124, 26);
            this.splitContainer10.Name = "splitContainer10";
            this.splitContainer10.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer10.Panel1
            // 
            this.splitContainer10.Panel1.Controls.Add(this.button16);
            this.splitContainer10.Panel1.Controls.Add(this.textBox19);
            this.splitContainer10.Panel1.Controls.Add(this.textBox18);
            this.splitContainer10.Panel1.Controls.Add(this.textBox17);
            this.splitContainer10.Panel1.Controls.Add(this.textBox16);
            this.splitContainer10.Panel1.Controls.Add(this.textBox15);
            this.splitContainer10.Panel1.Controls.Add(this.label30);
            this.splitContainer10.Panel1.Controls.Add(this.label29);
            this.splitContainer10.Panel1.Controls.Add(this.label28);
            this.splitContainer10.Panel1.Controls.Add(this.label27);
            this.splitContainer10.Panel1.Controls.Add(this.label26);
            this.splitContainer10.Panel1.Controls.Add(this.label25);
            this.splitContainer10.Panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.splitContainer10.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer10_Panel1_Paint);
            this.splitContainer10.Size = new System.Drawing.Size(831, 491);
            this.splitContainer10.SplitterDistance = 427;
            this.splitContainer10.SplitterWidth = 5;
            this.splitContainer10.TabIndex = 14;
            this.splitContainer10.Visible = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button16.Location = new System.Drawing.Point(318, 358);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(208, 43);
            this.button16.TabIndex = 11;
            this.button16.Text = "Return Main Menu";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // textBox19
            // 
            this.textBox19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox19.Location = new System.Drawing.Point(374, 283);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(236, 30);
            this.textBox19.TabIndex = 10;
            this.textBox19.Text = "Main Street, Richmond";
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox18.Location = new System.Drawing.Point(374, 238);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(236, 30);
            this.textBox18.TabIndex = 9;
            this.textBox18.Text = "10:00 AM";
            // 
            // textBox17
            // 
            this.textBox17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox17.Location = new System.Drawing.Point(374, 195);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(236, 30);
            this.textBox17.TabIndex = 8;
            this.textBox17.Text = "04/28/2025";
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.Location = new System.Drawing.Point(374, 148);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(236, 30);
            this.textBox16.TabIndex = 7;
            this.textBox16.Text = "Dental Check Up";
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.Location = new System.Drawing.Point(374, 106);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(236, 30);
            this.textBox15.TabIndex = 6;
            this.textBox15.Text = "Doctor Appointment";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(148, 286);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(66, 25);
            this.label30.TabIndex = 5;
            this.label30.Text = "Place";
            this.label30.Click += new System.EventHandler(this.label30_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(148, 242);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(121, 25);
            this.label29.TabIndex = 4;
            this.label29.Text = "Event Time";
            this.label29.Click += new System.EventHandler(this.label29_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(152, 198);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(118, 25);
            this.label28.TabIndex = 3;
            this.label28.Text = "Event Date";
            this.label28.Click += new System.EventHandler(this.label28_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(148, 151);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(181, 25);
            this.label27.TabIndex = 2;
            this.label27.Text = "Event Description";
            this.label27.Click += new System.EventHandler(this.label27_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(148, 111);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(129, 25);
            this.label26.TabIndex = 1;
            this.label26.Text = "Event Name";
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(314, 51);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(202, 36);
            this.label25.TabIndex = 0;
            this.label25.Text = "Event Details";
            // 
            // splitContainer11
            // 
            this.splitContainer11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.splitContainer11.Location = new System.Drawing.Point(93, 68);
            this.splitContainer11.Name = "splitContainer11";
            this.splitContainer11.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer11.Panel1
            // 
            this.splitContainer11.Panel1.Controls.Add(this.button18);
            this.splitContainer11.Panel1.Controls.Add(this.checkedListBox2);
            this.splitContainer11.Panel1.Controls.Add(this.label32);
            this.splitContainer11.Size = new System.Drawing.Size(784, 495);
            this.splitContainer11.SplitterDistance = 449;
            this.splitContainer11.SplitterWidth = 5;
            this.splitContainer11.TabIndex = 10;
            this.splitContainer11.Visible = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.Location = new System.Drawing.Point(338, 394);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(116, 42);
            this.button18.TabIndex = 2;
            this.button18.Text = "Next";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // checkedListBox2
            // 
            this.checkedListBox2.FormattingEnabled = true;
            this.checkedListBox2.Items.AddRange(new object[] {
            "Jack",
            "Bob",
            "Meghana",
            "Jessica",
            "John",
            "Jackson",
            "Martyna",
            "Cara",
            "Mya",
            "Blake",
            "Abbey",
            "Sumana",
            "Larry",
            "Brian"});
            this.checkedListBox2.Location = new System.Drawing.Point(208, 103);
            this.checkedListBox2.Name = "checkedListBox2";
            this.checkedListBox2.Size = new System.Drawing.Size(314, 234);
            this.checkedListBox2.TabIndex = 1;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(288, 42);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(158, 36);
            this.label32.TabIndex = 0;
            this.label32.Text = "Attendees";
            // 
            // splitContainer12
            // 
            this.splitContainer12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.splitContainer12.Location = new System.Drawing.Point(51, 95);
            this.splitContainer12.Name = "splitContainer12";
            this.splitContainer12.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer12.Panel1
            // 
            this.splitContainer12.Panel1.Controls.Add(this.button19);
            this.splitContainer12.Panel1.Controls.Add(this.checkedListBox3);
            this.splitContainer12.Panel1.Controls.Add(this.label33);
            this.splitContainer12.Size = new System.Drawing.Size(838, 492);
            this.splitContainer12.SplitterDistance = 404;
            this.splitContainer12.SplitterWidth = 5;
            this.splitContainer12.TabIndex = 15;
            this.splitContainer12.Visible = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.Location = new System.Drawing.Point(380, 352);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(108, 37);
            this.button19.TabIndex = 2;
            this.button19.Text = "Next";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // checkedListBox3
            // 
            this.checkedListBox3.FormattingEnabled = true;
            this.checkedListBox3.Items.AddRange(new object[] {
            "04/29/2025 : 2:00 PM - 4:30 PM",
            "04/30/2025 : 10:00 AM - 11:15 AM",
            "05/01/2025 : 1:30 PM - 2:45 PM",
            "05/08/2025 : 10:00 AM - 12:30 PM"});
            this.checkedListBox3.Location = new System.Drawing.Point(260, 120);
            this.checkedListBox3.Name = "checkedListBox3";
            this.checkedListBox3.Size = new System.Drawing.Size(320, 211);
            this.checkedListBox3.TabIndex = 1;
            this.checkedListBox3.SelectedIndexChanged += new System.EventHandler(this.checkedListBox3_SelectedIndexChanged);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(208, 46);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(541, 36);
            this.label33.TabIndex = 0;
            this.label33.Text = "Available slots to schedule a meeting";
            // 
            // splitContainer13
            // 
            this.splitContainer13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.splitContainer13.Location = new System.Drawing.Point(76, 31);
            this.splitContainer13.Name = "splitContainer13";
            // 
            // splitContainer13.Panel1
            // 
            this.splitContainer13.Panel1.Controls.Add(this.button20);
            this.splitContainer13.Panel1.Controls.Add(this.checkedListBox4);
            this.splitContainer13.Panel1.Controls.Add(this.label34);
            // 
            // splitContainer13.Panel2
            // 
            this.splitContainer13.Panel2.Controls.Add(this.checkedListBox5);
            this.splitContainer13.Panel2.Controls.Add(this.label35);
            this.splitContainer13.Size = new System.Drawing.Size(916, 489);
            this.splitContainer13.SplitterDistance = 461;
            this.splitContainer13.TabIndex = 16;
            this.splitContainer13.Visible = false;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.Location = new System.Drawing.Point(225, 428);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(111, 42);
            this.button20.TabIndex = 2;
            this.button20.Text = "Confirm";
            this.button20.UseVisualStyleBackColor = false;
            // 
            // checkedListBox4
            // 
            this.checkedListBox4.FormattingEnabled = true;
            this.checkedListBox4.Items.AddRange(new object[] {
            "Jack",
            "Bob",
            "Martyna",
            "Cara",
            "Blake",
            "Jessica",
            "Meghana"});
            this.checkedListBox4.Location = new System.Drawing.Point(152, 142);
            this.checkedListBox4.Name = "checkedListBox4";
            this.checkedListBox4.Size = new System.Drawing.Size(222, 234);
            this.checkedListBox4.TabIndex = 1;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(106, 49);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(290, 36);
            this.label34.TabIndex = 0;
            this.label34.Text = "Selected Attendees";
            // 
            // checkedListBox5
            // 
            this.checkedListBox5.FormattingEnabled = true;
            this.checkedListBox5.Items.AddRange(new object[] {
            "04/29/2025",
            "05/01/2025",
            "05/06/2025",
            "05/10/2025",
            "05/13/2025",
            "05/18/2025"});
            this.checkedListBox5.Location = new System.Drawing.Point(112, 142);
            this.checkedListBox5.Name = "checkedListBox5";
            this.checkedListBox5.Size = new System.Drawing.Size(282, 234);
            this.checkedListBox5.TabIndex = 1;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(144, 42);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(170, 36);
            this.label35.TabIndex = 0;
            this.label35.Text = "Availability";
            this.label35.UseWaitCursor = true;
            // 
            // panelInvalidUsername
            // 
            this.panelInvalidUsername.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelInvalidUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelInvalidUsername.Location = new System.Drawing.Point(147, 112);
            this.panelInvalidUsername.Name = "panelInvalidUsername";
            this.panelInvalidUsername.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // panelInvalidUsername.Panel1
            // 
            this.panelInvalidUsername.Panel1.Controls.Add(this.label36);
            this.panelInvalidUsername.Panel1.Controls.Add(this.button21);
            this.panelInvalidUsername.Panel1.Controls.Add(this.label37);
            this.panelInvalidUsername.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer8_Panel1_Paint);
            this.panelInvalidUsername.Size = new System.Drawing.Size(932, 514);
            this.panelInvalidUsername.SplitterDistance = 383;
            this.panelInvalidUsername.SplitterWidth = 5;
            this.panelInvalidUsername.TabIndex = 17;
            this.panelInvalidUsername.Visible = false;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(430, 88);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(261, 36);
            this.label36.TabIndex = 2;
            this.label36.Text = "Invalid Username";
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.Location = new System.Drawing.Point(369, 200);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(171, 48);
            this.button21.TabIndex = 1;
            this.button21.Text = "Login Screen";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.ReturnToLoginEvent);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.ForeColor = System.Drawing.Color.Red;
            this.label37.Location = new System.Drawing.Point(162, 88);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(232, 36);
            this.label37.TabIndex = 0;
            this.label37.Text = "Error Message:";
            // 
            // panelInvalidPassword
            // 
            this.panelInvalidPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelInvalidPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelInvalidPassword.Location = new System.Drawing.Point(141, 125);
            this.panelInvalidPassword.Name = "panelInvalidPassword";
            this.panelInvalidPassword.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // panelInvalidPassword.Panel1
            // 
            this.panelInvalidPassword.Panel1.Controls.Add(this.label38);
            this.panelInvalidPassword.Panel1.Controls.Add(this.button22);
            this.panelInvalidPassword.Panel1.Controls.Add(this.label39);
            this.panelInvalidPassword.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer8_Panel1_Paint);
            this.panelInvalidPassword.Size = new System.Drawing.Size(932, 514);
            this.panelInvalidPassword.SplitterDistance = 383;
            this.panelInvalidPassword.SplitterWidth = 5;
            this.panelInvalidPassword.TabIndex = 18;
            this.panelInvalidPassword.Visible = false;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(430, 88);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(258, 36);
            this.label38.TabIndex = 2;
            this.label38.Text = "Invalid Password";
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.Location = new System.Drawing.Point(363, 198);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(177, 48);
            this.button22.TabIndex = 1;
            this.button22.Text = "Login Screen";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.ReturnToLoginEvent);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.ForeColor = System.Drawing.Color.Red;
            this.label39.Location = new System.Drawing.Point(162, 88);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(232, 36);
            this.label39.TabIndex = 0;
            this.label39.Text = "Error Message:";
            // 
            // panelCreateErrorPasswords
            // 
            this.panelCreateErrorPasswords.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelCreateErrorPasswords.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelCreateErrorPasswords.Location = new System.Drawing.Point(159, 125);
            this.panelCreateErrorPasswords.Name = "panelCreateErrorPasswords";
            this.panelCreateErrorPasswords.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // panelCreateErrorPasswords.Panel1
            // 
            this.panelCreateErrorPasswords.Panel1.Controls.Add(this.label40);
            this.panelCreateErrorPasswords.Panel1.Controls.Add(this.button23);
            this.panelCreateErrorPasswords.Panel1.Controls.Add(this.label41);
            this.panelCreateErrorPasswords.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer8_Panel1_Paint);
            this.panelCreateErrorPasswords.Size = new System.Drawing.Size(932, 514);
            this.panelCreateErrorPasswords.SplitterDistance = 383;
            this.panelCreateErrorPasswords.SplitterWidth = 5;
            this.panelCreateErrorPasswords.TabIndex = 19;
            this.panelCreateErrorPasswords.Visible = false;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(430, 88);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(349, 36);
            this.label40.TabIndex = 2;
            this.label40.Text = "Passwords Don\'t Match";
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.Location = new System.Drawing.Point(386, 205);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(129, 48);
            this.button23.TabIndex = 1;
            this.button23.Text = "Back";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.ReturnToCreateAccountEvent);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.ForeColor = System.Drawing.Color.Red;
            this.label41.Location = new System.Drawing.Point(162, 88);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(232, 36);
            this.label41.TabIndex = 0;
            this.label41.Text = "Error Message:";
            // 
            // panelCreateErrorEmptyUsername
            // 
            this.panelCreateErrorEmptyUsername.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelCreateErrorEmptyUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelCreateErrorEmptyUsername.Location = new System.Drawing.Point(171, 137);
            this.panelCreateErrorEmptyUsername.Name = "panelCreateErrorEmptyUsername";
            this.panelCreateErrorEmptyUsername.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // panelCreateErrorEmptyUsername.Panel1
            // 
            this.panelCreateErrorEmptyUsername.Panel1.Controls.Add(this.label42);
            this.panelCreateErrorEmptyUsername.Panel1.Controls.Add(this.button24);
            this.panelCreateErrorEmptyUsername.Panel1.Controls.Add(this.label43);
            this.panelCreateErrorEmptyUsername.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer8_Panel1_Paint);
            this.panelCreateErrorEmptyUsername.Size = new System.Drawing.Size(932, 514);
            this.panelCreateErrorEmptyUsername.SplitterDistance = 383;
            this.panelCreateErrorEmptyUsername.SplitterWidth = 5;
            this.panelCreateErrorEmptyUsername.TabIndex = 20;
            this.panelCreateErrorEmptyUsername.Visible = false;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(430, 88);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(255, 36);
            this.label42.TabIndex = 2;
            this.label42.Text = "Username Empty";
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.Location = new System.Drawing.Point(386, 205);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(129, 48);
            this.button24.TabIndex = 1;
            this.button24.Text = "Back";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.ReturnToCreateAccountEvent);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.ForeColor = System.Drawing.Color.Red;
            this.label43.Location = new System.Drawing.Point(162, 88);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(232, 36);
            this.label43.TabIndex = 0;
            this.label43.Text = "Error Message:";
            // 
            // panelCreateErrorUsernameExists
            // 
            this.panelCreateErrorUsernameExists.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelCreateErrorUsernameExists.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelCreateErrorUsernameExists.Location = new System.Drawing.Point(183, 149);
            this.panelCreateErrorUsernameExists.Name = "panelCreateErrorUsernameExists";
            this.panelCreateErrorUsernameExists.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // panelCreateErrorUsernameExists.Panel1
            // 
            this.panelCreateErrorUsernameExists.Panel1.Controls.Add(this.label44);
            this.panelCreateErrorUsernameExists.Panel1.Controls.Add(this.button25);
            this.panelCreateErrorUsernameExists.Panel1.Controls.Add(this.label45);
            this.panelCreateErrorUsernameExists.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer8_Panel1_Paint);
            this.panelCreateErrorUsernameExists.Size = new System.Drawing.Size(932, 514);
            this.panelCreateErrorUsernameExists.SplitterDistance = 383;
            this.panelCreateErrorUsernameExists.SplitterWidth = 5;
            this.panelCreateErrorUsernameExists.TabIndex = 21;
            this.panelCreateErrorUsernameExists.Visible = false;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(430, 88);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(371, 36);
            this.label44.TabIndex = 2;
            this.label44.Text = "Username Exists Already";
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.Location = new System.Drawing.Point(386, 205);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(129, 48);
            this.button25.TabIndex = 1;
            this.button25.Text = "Back";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.ReturnToCreateAccountEvent);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.ForeColor = System.Drawing.Color.Red;
            this.label45.Location = new System.Drawing.Point(162, 88);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(232, 36);
            this.label45.TabIndex = 0;
            this.label45.Text = "Error Message:";
            // 
            // panelAddEventErrorInvalidTime
            // 
            this.panelAddEventErrorInvalidTime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelAddEventErrorInvalidTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelAddEventErrorInvalidTime.Location = new System.Drawing.Point(195, 162);
            this.panelAddEventErrorInvalidTime.Name = "panelAddEventErrorInvalidTime";
            this.panelAddEventErrorInvalidTime.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // panelAddEventErrorInvalidTime.Panel1
            // 
            this.panelAddEventErrorInvalidTime.Panel1.Controls.Add(this.label46);
            this.panelAddEventErrorInvalidTime.Panel1.Controls.Add(this.button26);
            this.panelAddEventErrorInvalidTime.Panel1.Controls.Add(this.label47);
            this.panelAddEventErrorInvalidTime.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer8_Panel1_Paint);
            this.panelAddEventErrorInvalidTime.Size = new System.Drawing.Size(932, 514);
            this.panelAddEventErrorInvalidTime.SplitterDistance = 383;
            this.panelAddEventErrorInvalidTime.SplitterWidth = 5;
            this.panelAddEventErrorInvalidTime.TabIndex = 22;
            this.panelAddEventErrorInvalidTime.Visible = false;
            this.panelAddEventErrorInvalidTime.Click += new System.EventHandler(this.ReturnToAddEventEvent);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(430, 88);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(276, 36);
            this.label46.TabIndex = 2;
            this.label46.Text = "Invalid Event Time";
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.Location = new System.Drawing.Point(386, 205);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(129, 48);
            this.button26.TabIndex = 1;
            this.button26.Text = "Back";
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.ReturnToAddEventEvent);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.ForeColor = System.Drawing.Color.Red;
            this.label47.Location = new System.Drawing.Point(162, 88);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(232, 36);
            this.label47.TabIndex = 0;
            this.label47.Text = "Error Message:";
            // 
            // panelAddEventErrorInvalidLength
            // 
            this.panelAddEventErrorInvalidLength.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelAddEventErrorInvalidLength.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelAddEventErrorInvalidLength.Location = new System.Drawing.Point(207, 174);
            this.panelAddEventErrorInvalidLength.Name = "panelAddEventErrorInvalidLength";
            this.panelAddEventErrorInvalidLength.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // panelAddEventErrorInvalidLength.Panel1
            // 
            this.panelAddEventErrorInvalidLength.Panel1.Controls.Add(this.label48);
            this.panelAddEventErrorInvalidLength.Panel1.Controls.Add(this.button27);
            this.panelAddEventErrorInvalidLength.Panel1.Controls.Add(this.label49);
            this.panelAddEventErrorInvalidLength.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer8_Panel1_Paint);
            this.panelAddEventErrorInvalidLength.Size = new System.Drawing.Size(932, 514);
            this.panelAddEventErrorInvalidLength.SplitterDistance = 383;
            this.panelAddEventErrorInvalidLength.SplitterWidth = 5;
            this.panelAddEventErrorInvalidLength.TabIndex = 23;
            this.panelAddEventErrorInvalidLength.Visible = false;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(430, 88);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(306, 36);
            this.label48.TabIndex = 2;
            this.label48.Text = "Invalid Event Length";
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.Location = new System.Drawing.Point(386, 205);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(129, 48);
            this.button27.TabIndex = 1;
            this.button27.Text = "Back";
            this.button27.UseVisualStyleBackColor = false;
            this.button27.Click += new System.EventHandler(this.ReturnToAddEventEvent);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.ForeColor = System.Drawing.Color.Red;
            this.label49.Location = new System.Drawing.Point(162, 88);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(232, 36);
            this.label49.TabIndex = 0;
            this.label49.Text = "Error Message:";
            // 
            // panelAddEventErrorConflicts
            // 
            this.panelAddEventErrorConflicts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelAddEventErrorConflicts.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelAddEventErrorConflicts.Location = new System.Drawing.Point(190, 163);
            this.panelAddEventErrorConflicts.Name = "panelAddEventErrorConflicts";
            this.panelAddEventErrorConflicts.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // panelAddEventErrorConflicts.Panel1
            // 
            this.panelAddEventErrorConflicts.Panel1.Controls.Add(this.label50);
            this.panelAddEventErrorConflicts.Panel1.Controls.Add(this.button28);
            this.panelAddEventErrorConflicts.Panel1.Controls.Add(this.label51);
            this.panelAddEventErrorConflicts.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer8_Panel1_Paint);
            this.panelAddEventErrorConflicts.Size = new System.Drawing.Size(932, 514);
            this.panelAddEventErrorConflicts.SplitterDistance = 383;
            this.panelAddEventErrorConflicts.SplitterWidth = 5;
            this.panelAddEventErrorConflicts.TabIndex = 24;
            this.panelAddEventErrorConflicts.Visible = false;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(402, 65);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(440, 36);
            this.label50.TabIndex = 2;
            this.label50.Text = "Conflicts occur with this event";
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button28.Location = new System.Drawing.Point(406, 185);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(129, 48);
            this.button28.TabIndex = 1;
            this.button28.Text = "Back";
            this.button28.UseVisualStyleBackColor = false;
            this.button28.Click += new System.EventHandler(this.ReturnToAddEventEvent);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.ForeColor = System.Drawing.Color.Red;
            this.label51.Location = new System.Drawing.Point(134, 65);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(232, 36);
            this.label51.TabIndex = 0;
            this.label51.Text = "Error Message:";
            // 
            // splitContainer3
            // 
            this.splitContainer3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.splitContainer3.Location = new System.Drawing.Point(162, 19);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.button30);
            this.splitContainer3.Panel1.Controls.Add(this.button29);
            this.splitContainer3.Panel1.Controls.Add(this.label52);
            this.splitContainer3.Size = new System.Drawing.Size(873, 393);
            this.splitContainer3.SplitterDistance = 287;
            this.splitContainer3.TabIndex = 10;
            this.splitContainer3.Visible = false;
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.Red;
            this.button30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.Location = new System.Drawing.Point(529, 173);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(112, 42);
            this.button30.TabIndex = 2;
            this.button30.Text = "NO";
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button29.Location = new System.Drawing.Point(277, 170);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(102, 43);
            this.button29.TabIndex = 1;
            this.button29.Text = "Yes";
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(195, 85);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(505, 36);
            this.label52.TabIndex = 0;
            this.label52.Text = "Are You Sure To Delete The Event";
            // 
            // splitContainer4
            // 
            this.splitContainer4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.splitContainer4.Location = new System.Drawing.Point(188, 17);
            this.splitContainer4.Name = "splitContainer4";
            this.splitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.button31);
            this.splitContainer4.Panel1.Controls.Add(this.label53);
            this.splitContainer4.Size = new System.Drawing.Size(764, 409);
            this.splitContainer4.SplitterDistance = 270;
            this.splitContainer4.TabIndex = 3;
            this.splitContainer4.Visible = false;
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button31.Location = new System.Drawing.Point(273, 125);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(162, 43);
            this.button31.TabIndex = 1;
            this.button31.Text = "Main Menu";
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(141, 57);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(401, 36);
            this.label53.TabIndex = 0;
            this.label53.Text = "Successfully Event Deleted";
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.splitContainer1.Location = new System.Drawing.Point(37, 39);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.button36);
            this.splitContainer1.Panel1.Controls.Add(this.button33);
            this.splitContainer1.Panel1.Controls.Add(this.checkedListBox6);
            this.splitContainer1.Panel1.Controls.Add(this.label54);
            this.splitContainer1.Size = new System.Drawing.Size(921, 475);
            this.splitContainer1.SplitterDistance = 409;
            this.splitContainer1.TabIndex = 3;
            this.splitContainer1.Visible = false;
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.Red;
            this.button36.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button36.Location = new System.Drawing.Point(485, 292);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(126, 49);
            this.button36.TabIndex = 3;
            this.button36.Text = "Back";
            this.button36.UseVisualStyleBackColor = false;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button33.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button33.Location = new System.Drawing.Point(320, 289);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(111, 52);
            this.button33.TabIndex = 2;
            this.button33.Text = "Edit";
            this.button33.UseVisualStyleBackColor = false;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // checkedListBox6
            // 
            this.checkedListBox6.FormattingEnabled = true;
            this.checkedListBox6.Location = new System.Drawing.Point(316, 106);
            this.checkedListBox6.Name = "checkedListBox6";
            this.checkedListBox6.Size = new System.Drawing.Size(333, 165);
            this.checkedListBox6.TabIndex = 1;
            this.checkedListBox6.SelectedIndexChanged += new System.EventHandler(this.checkedListBox6_SelectedIndexChanged);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(336, 46);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(278, 36);
            this.label54.TabIndex = 0;
            this.label54.Text = "Events Associated";
            // 
            // splitContainer5
            // 
            this.splitContainer5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.splitContainer5.Location = new System.Drawing.Point(124, 16);
            this.splitContainer5.Name = "splitContainer5";
            this.splitContainer5.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.button34);
            this.splitContainer5.Panel1.Controls.Add(this.label55);
            this.splitContainer5.Size = new System.Drawing.Size(983, 513);
            this.splitContainer5.SplitterDistance = 430;
            this.splitContainer5.TabIndex = 3;
            this.splitContainer5.Visible = false;
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button34.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button34.Location = new System.Drawing.Point(432, 153);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(159, 52);
            this.button34.TabIndex = 1;
            this.button34.Text = "Main Menu";
            this.button34.UseVisualStyleBackColor = false;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(335, 79);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(367, 32);
            this.label55.TabIndex = 0;
            this.label55.Text = "Event Successfully Edited";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1226, 738);
            this.Controls.Add(this.splitContainer9);
            this.Controls.Add(this.splitContainer5);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.splitContainer7);
            this.Controls.Add(this.splitContainer2);
            this.Controls.Add(this.splitContainer3);
            this.Controls.Add(this.splitContainer13);
            this.Controls.Add(this.splitContainer12);
            this.Controls.Add(this.splitContainer11);
            this.Controls.Add(this.splitContainer10);
            this.Controls.Add(this.splitContainer4);
            this.Controls.Add(this.splitContainer8);
            this.Controls.Add(this.panelLogin);
            this.Controls.Add(this.panelAddEvent);
            this.Controls.Add(this.panelAddEventErrorConflicts);
            this.Controls.Add(this.panelCreateErrorUsernameExists);
            this.Controls.Add(this.panelAddEventSuccess);
            this.Controls.Add(this.panelAddEventErrorInvalidLength);
            this.Controls.Add(this.panelAddEventErrorInvalidTime);
            this.Controls.Add(this.panelCreateAccountSuccess);
            this.Controls.Add(this.panelCreateErrorPasswords);
            this.Controls.Add(this.panelCreateAccount);
            this.Controls.Add(this.panelInvalidPassword);
            this.Controls.Add(this.panelInvalidUsername);
            this.Controls.Add(this.panelCreateErrorEmptyUsername);
            this.Name = "Form1";
            this.Text = "Calendar";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelLogin.Panel1.ResumeLayout(false);
            this.panelLogin.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelLogin)).EndInit();
            this.panelLogin.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.panelCreateAccount.Panel1.ResumeLayout(false);
            this.panelCreateAccount.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelCreateAccount)).EndInit();
            this.panelCreateAccount.ResumeLayout(false);
            this.panelCreateAccountSuccess.Panel1.ResumeLayout(false);
            this.panelCreateAccountSuccess.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelCreateAccountSuccess)).EndInit();
            this.panelCreateAccountSuccess.ResumeLayout(false);
            this.panelAddEvent.Panel1.ResumeLayout(false);
            this.panelAddEvent.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelAddEvent)).EndInit();
            this.panelAddEvent.ResumeLayout(false);
            this.panelAddEventSuccess.Panel1.ResumeLayout(false);
            this.panelAddEventSuccess.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelAddEventSuccess)).EndInit();
            this.panelAddEventSuccess.ResumeLayout(false);
            this.splitContainer7.Panel1.ResumeLayout(false);
            this.splitContainer7.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer7)).EndInit();
            this.splitContainer7.ResumeLayout(false);
            this.splitContainer9.Panel1.ResumeLayout(false);
            this.splitContainer9.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer9)).EndInit();
            this.splitContainer9.ResumeLayout(false);
            this.splitContainer8.Panel1.ResumeLayout(false);
            this.splitContainer8.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer8)).EndInit();
            this.splitContainer8.ResumeLayout(false);
            this.splitContainer10.Panel1.ResumeLayout(false);
            this.splitContainer10.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer10)).EndInit();
            this.splitContainer10.ResumeLayout(false);
            this.splitContainer11.Panel1.ResumeLayout(false);
            this.splitContainer11.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer11)).EndInit();
            this.splitContainer11.ResumeLayout(false);
            this.splitContainer12.Panel1.ResumeLayout(false);
            this.splitContainer12.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer12)).EndInit();
            this.splitContainer12.ResumeLayout(false);
            this.splitContainer13.Panel1.ResumeLayout(false);
            this.splitContainer13.Panel1.PerformLayout();
            this.splitContainer13.Panel2.ResumeLayout(false);
            this.splitContainer13.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer13)).EndInit();
            this.splitContainer13.ResumeLayout(false);
            this.panelInvalidUsername.Panel1.ResumeLayout(false);
            this.panelInvalidUsername.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelInvalidUsername)).EndInit();
            this.panelInvalidUsername.ResumeLayout(false);
            this.panelInvalidPassword.Panel1.ResumeLayout(false);
            this.panelInvalidPassword.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelInvalidPassword)).EndInit();
            this.panelInvalidPassword.ResumeLayout(false);
            this.panelCreateErrorPasswords.Panel1.ResumeLayout(false);
            this.panelCreateErrorPasswords.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelCreateErrorPasswords)).EndInit();
            this.panelCreateErrorPasswords.ResumeLayout(false);
            this.panelCreateErrorEmptyUsername.Panel1.ResumeLayout(false);
            this.panelCreateErrorEmptyUsername.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelCreateErrorEmptyUsername)).EndInit();
            this.panelCreateErrorEmptyUsername.ResumeLayout(false);
            this.panelCreateErrorUsernameExists.Panel1.ResumeLayout(false);
            this.panelCreateErrorUsernameExists.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelCreateErrorUsernameExists)).EndInit();
            this.panelCreateErrorUsernameExists.ResumeLayout(false);
            this.panelAddEventErrorInvalidTime.Panel1.ResumeLayout(false);
            this.panelAddEventErrorInvalidTime.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelAddEventErrorInvalidTime)).EndInit();
            this.panelAddEventErrorInvalidTime.ResumeLayout(false);
            this.panelAddEventErrorInvalidLength.Panel1.ResumeLayout(false);
            this.panelAddEventErrorInvalidLength.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelAddEventErrorInvalidLength)).EndInit();
            this.panelAddEventErrorInvalidLength.ResumeLayout(false);
            this.panelAddEventErrorConflicts.Panel1.ResumeLayout(false);
            this.panelAddEventErrorConflicts.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelAddEventErrorConflicts)).EndInit();
            this.panelAddEventErrorConflicts.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer5)).EndInit();
            this.splitContainer5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.SplitContainer panelLogin;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.SplitContainer panelCreateAccount;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.SplitContainer panelCreateAccountSuccess;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.SplitContainer panelAddEvent;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.SplitContainer panelAddEventSuccess;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.SplitContainer splitContainer7;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.SplitContainer splitContainer8;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.SplitContainer splitContainer9;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.SplitContainer splitContainer10;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.SplitContainer splitContainer11;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.CheckedListBox checkedListBox2;
        private System.Windows.Forms.SplitContainer splitContainer12;
        private System.Windows.Forms.CheckedListBox checkedListBox3;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.SplitContainer splitContainer13;
        private System.Windows.Forms.CheckedListBox checkedListBox4;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.CheckedListBox checkedListBox5;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.SplitContainer panelInvalidUsername;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.SplitContainer panelInvalidPassword;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.SplitContainer panelCreateErrorPasswords;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.SplitContainer panelCreateErrorEmptyUsername;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.SplitContainer panelCreateErrorUsernameExists;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.MonthCalendar monthCalendar2;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.SplitContainer panelAddEventErrorInvalidTime;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.SplitContainer panelAddEventErrorInvalidLength;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.SplitContainer panelAddEventErrorConflicts;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.CheckedListBox checkedListBox6;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
    }
}

